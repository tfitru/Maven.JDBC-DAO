Maven dependencies used for this demo: 

https://mvnrepository.com/artifact/mysql/mysql-connector-java/5.1.47

https://mvnrepository.com/artifact/junit/junit/4.12
